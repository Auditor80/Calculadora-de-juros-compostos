import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

document.addEventListener('DOMContentLoaded', () => {
    const valorInicialInput = document.getElementById('valorInicial');
    const aporteMensalInput = document.getElementById('aporteMensal');
    const taxaJurosAnualInput = document.getElementById('taxaJurosAnual');
    const periodoAnosInput = document.getElementById('periodoAnos');
    const calcularBtn = document.getElementById('calcularBtn');

    const resultadoValorFinalEl = document.getElementById('resultadoValorFinal');
    const resultadoTotalInvestidoEl = document.getElementById('resultadoTotalInvestido');
    const resultadoJurosEl = document.getElementById('resultadoJuros');

    const ctx = document.getElementById('growthChart').getContext('2d');
    let growthChart;

    function formatCurrency(value) {
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }

    function calculateAndDisplay() {
        const principal = parseFloat(valorInicialInput.value) || 0;
        const monthlyContribution = parseFloat(aporteMensalInput.value) || 0;
        const annualRate = parseFloat(taxaJurosAnualInput.value) || 0;
        const years = parseInt(periodoAnosInput.value) || 0;

        if (years <= 0) return;

        const monthlyRate = annualRate / 100 / 12;
        const totalMonths = years * 12;

        let futureValue = principal;
        let totalInvested = principal;
        
        const labels = ['Ano 0'];
        const accumulatedData = [principal];
        const investedData = [principal];

        for (let month = 1; month <= totalMonths; month++) {
            futureValue += monthlyContribution;
            futureValue *= (1 + monthlyRate);

            if (month % 12 === 0) {
                const currentYear = month / 12;
                totalInvested = principal + (monthlyContribution * month);
                
                labels.push(`Ano ${currentYear}`);
                accumulatedData.push(futureValue);
                investedData.push(totalInvested);
            }
        }
        
        // Ensure the final values are correctly represented if not a whole number of years
        totalInvested = principal + (monthlyContribution * totalMonths);
        const totalInterest = futureValue - totalInvested;

        resultadoValorFinalEl.textContent = formatCurrency(futureValue);
        resultadoTotalInvestidoEl.textContent = formatCurrency(totalInvested);
        resultadoJurosEl.textContent = formatCurrency(totalInterest);

        updateChart(labels, accumulatedData, investedData);
    }

    function updateChart(labels, accumulatedData, investedData) {
        if (growthChart) {
            growthChart.destroy();
        }

        growthChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Valor Total Acumulado',
                        data: accumulatedData,
                        borderColor: '#007bff',
                        backgroundColor: 'rgba(0, 123, 255, 0.1)',
                        fill: true,
                        tension: 0.1
                    },
                    {
                        label: 'Total Investido',
                        data: investedData,
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        fill: false,
                        tension: 0.1,
                        borderDash: [5, 5]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + (value / 1000) + 'k';
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += formatCurrency(context.parsed.y);
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    }

    calcularBtn.addEventListener('click', calculateAndDisplay);
    
    // Initial calculation on page load
    calculateAndDisplay();
});

